# Comparative analysis of off-loading algorithms for snapshot positioning

## Guildlines
### <u>Dependencies</u>
Please download the library source from https://github.com/JonasBchrt/snapshot-gnss-algorithms, store all of the files of it and the ones in the respository in the same directory before running it.
! Python version used for this notebook is 3.7.1, remember to install all the packages in `requirements.txt`. It's very recommended to use this in a conda environment to avoid clashing with your own computer python.
### <u>Algorithms</u>
There are a total of six algorithms to be assessed:

- **"ls-single"**
- **"ls-linear"**
- **"ls-combo"**
- **"ls-sac"**
- **"mle"**
- **"ls-sac/mle"**

### <u>Experiments</u>
There are a total of three experiments, each of which will test the algorithms with different numbers of GNSS:

- Experiment 1: GPS + Galileo + BeiDou 
- Experiment 2: GPS + Galileo 
- Experiment 3: GPS 

The more satellites available, the slower and the more robust the experiment will be able to test the algorithms.

### <u>Datasets</u>
Multiple datasets, ranging from static to dynamic scenarios, are indexed from A to M. They are binary files that contain IQ data:
| Category | Static | Dynamic | Sampling Frequency (MHz) | Snapshot Duration (e-3s) | Snapshots | Source |
|:--------:|:------:|:-------:|:------------------------:|:------------------------:|:---------:|:------:|
| A        | x      |         | 4                        | 12                       | 181       | UO*     |
| B        | x      |         | 4                        | 12                       | 14        | UO     |
| C        | x      |         | 4                        | 12                       | 6         | UO     |
| D        | x      |         | 4                        | 12                       | 24        | UO     |
| E        |        | x       | 4                        | 12                       | 380       | UO     |
| F        |        | x       | 4                        | 12                       | 339       | UO     |
| G        |        | x       | 4                        | 12                       | 693       | UO     |
| H        |        | x       | 4                        | 12                       | 628       | UO     |
| I        |        | x       | 4                        | 12                       | 1023      | UO     |
| J        |        | x       | 4                        | 12                       | 346       | UO     |
| K        |        | x       | 4                        | 12                       | 66        | UO     |
| L        | x      |         | 5                        | 20                       | 63        | TUNI*   |
| M        | x      |         | 10                       | 20                       | 63        | TUNI   |

Based on your interest, you can choose one scenario or more to run the assessment. More information of the available scenarios can be found in data.txt in the project folder.

!!! L,M datasets are not processed and pickled yet.

<small>**UO = University of Oxford, TUNI=Tampere University*</small>

### Data Structure
All the data is stored in `all_experiments`. You can access the data with. For example:
- `all_experiments[n]` with n = 1,2,3: access to object that contains all data of the chosen experiment
- `all_experiments[n].errors[modes[1]]`: access horizontal errors for only ls-single in experiment n
- `all_experiments[n].errors[modes[1]]["A"]`: access horizontal errors for only data set A of ls-single in experiment n

The construction of all_experiments will take approximately 4h to 5h. So the snapshots are already processed and "pickled" into a file, and loaded again for assessment.


```python
import pickle
import pandas as pd
from experiment_results import (
    Results_for_experiment, plot_culmulative_errors, generate_statistics,
    statistics, plot_ENU_scenario, plot_EN, plotMap)

# These are used for indexing
modes = {1:"ls-single", 2:"ls-linear", 3:"ls-combo", 4:"ls-sac", 5:"mle", 6:"ls-sac/mle"}  
scenarios = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"] # Index from 0:10

# Now you load your dictionary of objects back, ready to be used
with open('all_experiments.pkl', 'rb') as file:
    all_experiments = pickle.load(file)
```

## Visual analysis
### <u>Cumulative of horizontal or EN errors</u>
<small>*Recreating the results from Jonas Beuchert and Alex Rogers. 2021. SnapperGPS: Algorithms for Energy-Efficient Low-Cost Location Estimation Using GNSS Signal Snapshots. https://doi.org/10.1145/3485730.3485931*</small>


```python
for experiment in all_experiments.values():
    plot_culmulative_errors(experiment, figsize=6)
```


    
![png](output_5_0.png)
    



    
![png](output_5_1.png)
    



    
![png](output_5_2.png)
    


### <u>Statistics</u>
For the `statistics` function, you can choose what you want to show; here are the possible inputs for the parameter `whattoshow`:

- `"all"`: Shows all statistics.
- `"E"`: East error statistics.
- `"N"`: North error statistics.
- `"U"`: Up error statistics.
- `"ENU"`: All East, North, and Up error statistics.
- `"RMSE"`: Root Mean Square Error, both 2D and 3D.
- `"2D"`: Specifically for RMSE 2D statistics.
- `"3D"`: Specifically for RMSE 3D statistics.
- `"Runtime"`: Mean runtime statistics.
- `"Min"`: Minimum error values for E, N, U.
- `"Max"`: Maximum error values for E, N, U.
- `"Std"`: Standard deviation for E, N, U errors.
- `"Mean"`: Mean values for E, N, U errors.
- `"Error < 200m"`: Percentage of errors under 200 meters.
- `"% Error < 200m"`: An alternative keyword for percentage of errors under 200 meters.

You can also put more than one inputs for whattoshow, eg., `whattoshow` = `"mean median"`


```python
## Get statistics about ENU errors
for exp, res_obj in all_experiments.items():
    print(f"Statistics for Experiment: {exp}")
    
    df_stats = generate_statistics(res_obj) 
    # filter the statistics
    filtered_stats = statistics(df_stats, whattoshow="all")
    
    print(filtered_stats)
    print("\n" + "-"*50 + "\n") 
```

    Statistics for Experiment: 1
             Mode         Min E         Min N         Min U         Max E  \
    0   ls-single -4.844527e+06 -4.391714e+06 -1.079506e+07  4.808840e+06   
    1   ls-linear -9.943210e+03 -1.012054e+04 -1.479850e+01  9.947048e+03   
    2    ls-combo -1.418269e+04 -1.021013e+04 -2.645548e+01  1.227014e+04   
    3      ls-sac -8.425802e+03 -8.518164e+03 -1.164688e+01  8.358641e+03   
    4         mle -1.272342e+04 -1.093606e+04 -1.756518e+01  1.082615e+04   
    5  ls-sac/mle -1.486975e+04 -1.011625e+04 -2.905558e+01  1.513044e+04   
    
              Max N         Max U           SD E           SD N           SD U  \
    0  4.603663e+06 -1.882556e-06  168503.917023  169537.994447  263645.862569   
    1  1.018313e+04 -1.710863e-07    2759.452972    3296.867347       1.671494   
    2  1.450990e+04 -6.160018e-08    2799.292086    3347.294940       1.781404   
    3  9.993226e+03 -5.392186e-08    2784.875408    3337.492206       1.652970   
    4  1.097307e+04 -2.065247e-08    2865.786776    3431.411087       1.909626   
    5  1.192136e+04 -5.243399e-08    2900.174541    3426.383317       1.986127   
    
            Mean E       Mean N       Mean U     Median E  Median N  Median U  \
    0 -1146.909788 -2699.192721 -9946.695000 -1400.415407 -3.368957 -1.129782   
    1  -787.562998   352.318379    -1.506444 -1292.826136  5.469523 -0.888659   
    2  -816.255609   356.642532    -1.553887 -1382.270986  1.329089 -0.937578   
    3  -809.027274   362.540412    -1.541863 -1424.996936  4.629556 -0.969248   
    4  -805.203866   397.281771    -1.629079 -1419.947069  5.532650 -1.008991   
    5  -791.080492   411.783999    -1.641042 -1400.709849  5.497258 -1.011367   
    
             RMSE 2D        RMSE 3D  % Error < 200m  Mean Runtime (s)  
    0  239050.836972  356024.409623       81.081081          0.327413  
    1    4385.008406    4385.008984       96.756757          0.327413  
    2    4453.525201    4453.525828       97.432432          0.327413  
    3    4436.253594    4436.254169       96.027027          0.327413  
    4    4559.989251    4559.989941       97.054054          0.327413  
    5    4576.733487    4576.734212       96.891892          0.327413  
    
    --------------------------------------------------
    
    Statistics for Experiment: 2
             Mode         Min E         Min N         Min U         Max E  \
    0   ls-single -5.934976e+06 -6.330705e+06 -7.237568e+06  5.161217e+06   
    1   ls-linear -9.769189e+03 -1.014380e+04 -1.339891e+01  9.558020e+03   
    2    ls-combo -1.313218e+04 -1.283780e+04 -2.206580e+01  1.379928e+04   
    3      ls-sac -1.135666e+04 -1.153516e+04 -1.339889e+01  7.920350e+03   
    4         mle -1.097900e+04 -1.086428e+04 -1.818617e+01  1.111019e+04   
    5  ls-sac/mle -1.908402e+04 -1.257894e+04 -3.080038e+01  1.082494e+04   
    
              Max N         Max U           SD E           SD N           SD U  \
    0  3.663035e+06 -1.461535e-06  167845.209207  168076.161793  178297.524350   
    1  1.063371e+04 -6.334846e-08    2749.427941    3299.632569       1.672602   
    2  9.560846e+03 -4.261254e-07    2810.513753    3345.270577       1.769121   
    3  9.332255e+03 -4.563006e-08    2788.461881    3352.327671       1.670832   
    4  1.094563e+04 -5.516251e-08    2906.358932    3433.158773       1.960718   
    5  1.088480e+04 -3.619238e-08    2900.684961    3438.727024       2.017680   
    
            Mean E      Mean N       Mean U     Median E   Median N  Median U  \
    0 -1381.492822   30.720937 -6922.840165 -1308.009546  12.804404 -1.133654   
    1  -777.737034  341.176794    -1.501745 -1252.691751   7.698513 -0.860227   
    2  -800.962568  334.080345    -1.554592 -1355.473726   3.931550 -0.929547   
    3  -811.285813  345.155491    -1.550532 -1410.758498   9.320638 -0.968409   
    4  -792.927102  362.028998    -1.644706 -1414.084312   9.998166 -0.991866   
    5  -823.243090  359.050538    -1.648794 -1407.284964   9.040554 -1.006033   
    
             RMSE 2D        RMSE 3D  % Error < 200m  Mean Runtime (s)  
    0  237536.354866  297088.291234       79.081081          0.156044  
    1    4378.150933    4378.151510       95.648649          0.156044  
    2    4454.545263    4454.545886       96.162162          0.156044  
    3    4448.700648    4448.701232       94.702703          0.156044  
    4    4581.844583    4581.845298       96.243243          0.156044  
    5    4587.533462    4587.534202       96.108108          0.156044  
    
    --------------------------------------------------
    
    Statistics for Experiment: 3
             Mode         Min E         Min N         Min U         Max E  \
    0   ls-single -4.086014e+06 -3.240411e+06 -1.232315e+07  2.153437e+06   
    1   ls-linear -1.144868e+04 -1.325358e+04 -5.738872e+01  2.676173e+04   
    2    ls-combo -2.048526e+04 -1.515762e+04 -5.084933e+01  1.367377e+04   
    3      ls-sac -1.224684e+04 -1.418490e+04 -6.000481e+01  1.405170e+04   
    4         mle -1.251142e+04 -1.567464e+04 -2.868674e+01  1.097119e+04   
    5  ls-sac/mle -1.140422e+04 -1.418490e+04 -1.814482e+01  1.276087e+04   
    
              Max N         Max U           SD E           SD N           SD U  \
    0  4.912457e+06 -1.582045e-10  157569.319594  204644.020975  235411.199988   
    1  1.207730e+04 -2.572674e-07    2657.417863    3330.004457       2.272735   
    2  2.110739e+04 -2.384484e-07    2870.892912    3624.400690       2.523383   
    3  2.480860e+04 -3.025922e-07    2914.863708    3755.911617       2.451954   
    4  1.082994e+04 -3.157214e-07    2952.578432    3523.039766       2.136256   
    5  1.400110e+04 -2.128318e-07    3070.950150    3755.835021       2.421067   
    
            Mean E       Mean N       Mean U     Median E   Median N  Median U  \
    0 -6330.565497  4447.957935 -9589.108620 -1272.810186 -10.058174 -1.912546   
    1  -633.704319   180.920546    -1.456154  -724.727861 -16.724595 -0.555111   
    2  -682.391414   205.717301    -1.714819  -895.716785 -12.256838 -0.728667   
    3  -787.804843   235.231159    -1.823991 -1265.935917 -10.771823 -1.080576   
    4  -766.708821   318.565275    -1.709409 -1336.718918   2.495052 -0.972304   
    5  -733.743552   212.467196    -1.889802 -1253.749599  -4.953791 -1.093937   
    
             RMSE 2D        RMSE 3D  % Error < 200m  Mean Runtime (s)  
    0  258393.355540  349682.013079       67.864865          0.125257  
    1    4311.045440    4311.046285       76.729730          0.125257  
    2    4678.277901    4678.278896       80.540541          0.125257  
    3    4824.859861    4824.860828       76.378378          0.125257  
    4    4671.065707    4671.066508       88.702703          0.125257  
    5    4911.268007    4911.268968       84.621622          0.125257  
    
    --------------------------------------------------
    
    

### <u>ENU errors plot</u>


```python
# Plot ENU errors
for experiment in all_experiments.values():
    # for all static scenarios
    plot_ENU_scenario(experiment, scenarios[:5], figsize=6)
#     # for all dynamic scenarios
#     plot_ENU_scenario(experiment, scenarios[4:], figsize=6)
#     # for all scenarios
#     plot_ENU_scenario(experiment, scenarios, figsize=6)
```


    
![png](output_9_0.png)
    



    
![png](output_9_1.png)
    



    
![png](output_9_2.png)
    



```python
### <u>EN plot: horizontal error but in 2D plane </u>
```


```python
for experiment in all_experiments.values():
    plot_EN(experiment,scenarios[:5],figsize=7)
```


    
![png](output_11_0.png)
    



    
![png](output_11_1.png)
    



    
![png](output_11_2.png)
    


### <u>Map plot: data points shown in real map</u>
#### Intructions for function input
`extent` is for bounding box of the graph, recommending for this data sets:
 - static lattitude, longtitude extent around 3km from reference point is [0.027, 0.025]
 - dynamic extent around 10km from reference point is [0.0901 0.09]
 - scale: how much zoom-in you want
 But the general tip is tighten the extent and keep the zoop around 15-18


```python
# Plots geographic positions on a map
for experiment in all_experiments.values():
    plotMap(experiment, scenarios[0], extent=[0.004, 0.003], scale=16, figsize=6)
```


    
![png](output_13_0.png)
    



    
![png](output_13_1.png)
    



    
![png](output_13_2.png)
    



```python

```
